import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::connection-event.connection-event');
