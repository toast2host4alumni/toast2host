import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::privacy-request.privacy-request');
