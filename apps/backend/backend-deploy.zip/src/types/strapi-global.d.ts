declare const strapi: any;

